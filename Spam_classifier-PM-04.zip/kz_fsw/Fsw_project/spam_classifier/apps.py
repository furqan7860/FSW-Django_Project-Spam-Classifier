from django.apps import AppConfig


class SpamClassifierConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spam_classifier'
